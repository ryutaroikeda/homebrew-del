#`del`

##Installation
Type `make install` to install. The binaries are moved to ~/bin.
Type `make uninstall` to uninstall.
Run some tests by typing `make test`.

##Usage
Type `del <filenames>` to move unwanted files to the /tmp/trash directory.

##Support
POSIX.
